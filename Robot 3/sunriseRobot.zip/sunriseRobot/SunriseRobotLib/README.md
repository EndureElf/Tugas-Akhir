## Installation Steps

cd py_install

sudo python3 setup.py install

